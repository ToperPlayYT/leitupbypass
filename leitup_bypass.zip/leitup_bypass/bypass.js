alert("LeitUP Bypassed");
window.location.href = document.getElementsByClassName("form-control")[0].placeholder;